package com.github.drinking_buddies.webservices.facebook;

//Facebook PagingData POJO
public class PagingData {

	private String next;
	private String previous;
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrevious() {
		return previous;
	}
	public void setPrevious(String previous) {
		this.previous = previous;
	}
	
	
}
